import {
  ActivityIndicator,
  Dimensions,
  FlatList,
  Image,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import React, {useEffect, useState} from 'react';
import Card from '../component/Card';

const Home = ({navigation}) => {
  const [loader, setLoader] = useState(false);
  const [data, setData] = useState([]);

  useEffect(() => {
    getItemList();
  }, []);

  const getItemList = async () => {
    setLoader(true);
    let url =
      'https://lza4vi7uuvokxmbo5kmt4ou7i40nzhbg.lambda-url.us-east-1.on.aws/';
    fetch(url)
      .then(res => res.json())
      .then(res => {
        setData(res);
        setLoader(false);
      })
      .catch(e => {
        console.log(e);
        setData([]);
        setLoader(false);
      });
  };
  const ItemBox = ({item, index}) => {
    console.log(item.image);
    return (
      <TouchableOpacity
        onPress={() => {
          navigation.navigate('Details', {item});
        }}>
        <Card item={item} />
      </TouchableOpacity>
    );
  };
  return (
    <View>
      <ActivityIndicator animating={loader} size={'large'} />
      <FlatList data={data} renderItem={ItemBox} />
    </View>
  );
};

export default Home;

const styles = StyleSheet.create({
  itemView: {
    flex: 1,
    flexDirection: 'row',
    backgroundColor: 'red',
    marginVertical: 16,
    alignItems: 'center',
    justifyContent: 'center',
  },
});
