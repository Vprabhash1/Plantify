import {Dimensions, Image, StyleSheet, Text, View} from 'react-native';
import React from 'react';
import Card from '../component/Card';

const Details = ({route}) => {
  const item = route.params.item;
  return (
    <View style={{flex: 1}}>
      <View style={{marginStart: 8}}>
        <Text style={styles.nameText}>{item.name}</Text>
        <Text style={styles.categoryText}>{item.category}</Text>
      </View>
      <View
        style={{
          justifyContent: 'center',
          alignItems: 'center',
        }}>
        <View style={{flexDirection: 'column'}}>
          <Text style={styles.detailText}>{'price'}</Text>
          <Text style={styles.detailText2}>{item.price}</Text>
          <Text style={styles.detailText}>{'size'}</Text>
          <Text style={styles.detailText2}>{item.size}</Text>
        </View>
      </View>
      <View
        style={{
          flexDirection: 'row',
          justifyContent: 'space-evenly',
          alignItems: 'center',
        }}>
        <Image
          source={require('../assets/images/heart.png')}
          style={{
            width: '20%',
            height: Dimensions.get('window').height / 12,
          }}
          resizeMode={'contain'}
        />
        <Image
          source={require('../assets/images/heart.png')}
          style={{
            width: '20%',
            height: Dimensions.get('window').height / 12,
          }}
          resizeMode={'contain'}
        />
        <Image
          source={{uri: item.image}}
          style={{
            width: '50%',
            height: Dimensions.get('window').height / 4,
          }}
          resizeMode={'contain'}
        />
      </View>
    </View>
  );
};

export default Details;

const styles = StyleSheet.create({
  nameText: {fontSize: 14, marginStart: 8},
  categoryText: {fontSize: 38, marginStart: 8},
  detailText: {fontSize: 12, marginStart: 8, textTransform: 'capitalize'},
  detailText2: {fontSize: 16, marginStart: 8},
});
