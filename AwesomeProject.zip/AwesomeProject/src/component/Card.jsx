import {Dimensions, Image, StyleSheet, Text, View} from 'react-native';
import React from 'react';

export default function Card({item}) {
  return (
    <View style={styles.itemView}>
      <View style={{flexDirection: 'column'}}>
        <Text style={{fontSize: 14}}>{item.name}</Text>
        <Text style={{fontSize: 32}}>{item.category}</Text>
      </View>
      <Image
        source={{uri: item.image}}
        style={{width: '50%', height: Dimensions.get('window').height / 4}}
        resizeMode={'contain'}
      />
    </View>
  );
}

const styles = StyleSheet.create({
    itemView: {
        flex: 1,
        flexDirection: 'row',
        backgroundColor: 'red',
        marginVertical: 16,
        alignItems: 'center',
        justifyContent: 'center',
      },
});
